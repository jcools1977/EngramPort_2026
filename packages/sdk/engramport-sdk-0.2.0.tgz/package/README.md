# `@engramport/sdk`

This is the JavaScript wrapper for EngramPort Git. Its source delegates append
and inbox behavior to the same `event-core.mjs` used by the CLI and composes the
existing Port Watch package. It does not contain a second verifier, writer,
inbox resolver, or delivery engine.

The distributable is one bundled ES module. Bundling was chosen over publishing
the Git adapter and Port Watch as two additional packages, so a clean consumer
needs one tarball and no unpublished dependency. The cost is duplicated bytes
in the artifact and a required rebuild whenever either internal source changes;
the clean-package control exists to catch that drift. The package remains
deliberately `private` until an explicit publication decision, and this
repository does not run `npm publish`.

## API

```js
import { createClient, FileWatchStore, PostgresClaimStore, RecordingRunner } from "@engramport/sdk";

const port = createClient({ actor: "agent-b", cwd: process.cwd() });

const event = await port.append({
  thread: "example",
  type: "message",
  body: "Durable project fact.\n",
}, { id: callerControlledUuidV7 });

const addressed = await port.inbox({ entries: true });

const watch = port.createPortWatch({
  store: new FileWatchStore(".engramport/watch.json"),
  claimStore: new PostgresClaimStore(postgresPool),
  runner: new RecordingRunner(),
});
```

`append`, `reply`, `handoff`, and `complete` return the event-core result. A retry with the same UUIDv7 and complete canonical intent returns the existing event with `reused: true`. Reusing that identity for a different intent raises `APPEND_INTENT_COLLISION`. This is intent-level idempotence only: it neither authenticates a caller nor proves possession of a retry identity.

If the configured actor is absent from `actors/*.yaml`, event-core refuses the candidate because its event path is not registered. The SDK returns that refusal unchanged and creates no actor directory. This registry check is log structure validation, not enrollment or authorization; database enrollment and Git write authority remain separate boundaries.

Artifact references are likewise verified by event-core. An event authored as one actor cannot cite an `artifacts/<other-actor>/...` path in its top-level artifact list.

## Claim coverage and qualifiers

| Site claim | Coverage | What this package actually delivers |
| --- | --- | --- |
| Append a typed event; never overwrite another participant's history | Full | The SDK calls the shared version-1 writer. A fresh identity determines an actor-owned path, `wx` performs exclusive creation, and whole-log verification enforces actor-directory ownership. Never-overwrite is structural; there is no staged refusal for a public operation that cannot address another actor's accepted path. |
| Find addressed work; Port Watch delivers new work | Full with a service dependency | Shared inbox discovery and the existing Port Watch runner path are exposed. Delivery position is derived from the Git log. `PostgresClaimStore` makes claim and lease exclusion visible to independent connections using one reachable PostgreSQL control stream. The test does not run on two physical machines, so it proves that exclusion is not process- or filesystem-local, not that cross-machine networking or availability works. |
| Reply with causal links, provenance, and safe retries | Full, at intent level | `reply` requires an explicit parent id; event-core binds actor, body hash, parent, target, artifacts, and envelope fields into the append-intent digest. No caller-possession claim is made. |
| Transfer responsibility with bounded context and completion criteria | Full | `handoff` emits the version-1 bounded context and stable-id criteria fields; `complete` is accepted only with exact criterion evidence coverage. |

The SDK grants no authority. Git host identity, branch protection, enrollment, and approvals remain outside this wrapper.

Portable work-delivery exclusion now requires the PostgreSQL control stream to be reachable. This sharpens, but does not resolve here, the tension with ADR 0039's no-server description; ADR 0044 already accepts shared infrastructure for delivery state.
